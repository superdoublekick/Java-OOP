package Card_Suits_1;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Card Suits:");
        Arrays.stream(CardSuits.values()).forEach(System.out::println);

        

    }
}
