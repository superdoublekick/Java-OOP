package NeedForSpeed_4;

public class Motorcycle extends Vehicle{
    public Motorcycle(double fuel, int horsepower) {
        super(fuel, horsepower);
    }
}
