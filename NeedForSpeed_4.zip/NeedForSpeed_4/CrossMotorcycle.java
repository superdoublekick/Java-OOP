package NeedForSpeed_4;

public class CrossMotorcycle extends Motorcycle{
    public CrossMotorcycle(double fuel, int horsepower) {
        super(fuel, horsepower);
    }
}
