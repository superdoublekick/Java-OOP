package NeedForSpeed_4;

public class FamilyCar extends Car{
    public FamilyCar(double fuel, int horsepower) {
        super(fuel, horsepower);
    }
}
