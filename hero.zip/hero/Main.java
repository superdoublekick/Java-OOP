package hero;


public class Main {
    public static void main(String[] args) {
        // Create a Hero instance
        Hero hero = new Hero("HeroName", 10);

        // Print out the details using toString()
        System.out.println(hero);
    }
}

