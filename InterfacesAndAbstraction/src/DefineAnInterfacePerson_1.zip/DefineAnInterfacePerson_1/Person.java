package DefineAnInterfacePerson_1;

public interface Person {
    
    
    public String getName();

    public int getAge();


}
