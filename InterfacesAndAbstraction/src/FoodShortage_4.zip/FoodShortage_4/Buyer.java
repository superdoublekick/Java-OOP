package FoodShortage_4;

public interface Buyer {


    void buyFood();

    int getFood();

}
