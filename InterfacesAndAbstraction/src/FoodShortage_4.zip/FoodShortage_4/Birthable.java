package FoodShortage_4;

public interface Birthable {

    public String getBirthDate();
}
