package FoodShortage_4;

public interface Person {
    
    
    public String getName();

    public int getAge();


}
