package BirthdayCelebration_3;

public interface Identifiable {


    public String getId();
}
