package MultipleImplementation_2;

public interface Person {
    
    
    public String getName();

    public int getAge();


}
