package MultipleImplementation_2;

public interface Identifiable {


    public String getId();
}
