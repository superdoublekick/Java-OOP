package MultipleImplementation_2;

public interface Birthable {

    public String getBirthDate();
}
