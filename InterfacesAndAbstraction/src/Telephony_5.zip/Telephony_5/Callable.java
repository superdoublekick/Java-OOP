package Telephony_5;

public interface Callable {

    String call();
}
