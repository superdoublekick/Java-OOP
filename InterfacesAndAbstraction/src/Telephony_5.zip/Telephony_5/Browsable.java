package Telephony_5;

public interface Browsable {


     String browse();

}
