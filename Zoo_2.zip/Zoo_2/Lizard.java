package Zoo_2;

public class Lizard extends Reptile{
    public Lizard(String name) {
        super(name);
    }
}
