package PizzaCalories_4;

public enum ToppingType {
    Meat,
    Veggies,
    Cheese,
    Sauce;

}
