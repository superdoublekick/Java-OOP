package PizzaCalories_4;

public enum FlourType {
    White,
    Wholegrain;
}
