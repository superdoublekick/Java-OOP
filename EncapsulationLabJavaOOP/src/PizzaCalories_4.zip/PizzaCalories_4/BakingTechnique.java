package PizzaCalories_4;

public enum BakingTechnique {
    Crispy,
    Chewy,
    Homemade;

}
