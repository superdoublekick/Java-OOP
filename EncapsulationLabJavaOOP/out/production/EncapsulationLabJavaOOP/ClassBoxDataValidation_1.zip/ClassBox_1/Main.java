package ClassBox_1;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        double length = Double.parseDouble(scanner.nextLine());
        double width = Double.parseDouble(scanner.nextLine());
        double height = Double.parseDouble(scanner.nextLine());

        Box box = new Box(length,width,height);

        double calculateSurfaceAreaResult = box.calculateSurfaceArea();
        double calculateLateralSurfaceAreaResult = box.calculateLateralSurfaceArea();
        double calculateVolumeResult = box.calculateVolume();

        System.out.println("Surface Area - " + calculateSurfaceAreaResult);
        System.out.println("Lateral Surface Area - " + calculateLateralSurfaceAreaResult);
        System.out.println("Volume - " + calculateVolumeResult);

    }
}
