package AnimalFarm_2;

public class Chicken {
    private String name;
    private int age;

    public Chicken(String name, int age) {
        if(name.length() <1) {
            throw new IllegalArgumentException("Name cannot be empty.");
        }
        setName(name);
        if(age<0 || age >15) {
            throw new IllegalArgumentException("Age should be between 0 and 15.");
        }
        setAge(age);
    }

    private void setName(String name) {
        this.name = name;
    }

    private void setAge(int age) {
        this.age = age;
    }
    public double productPerDay() {
        return this.calculateProductPerDay();
    }
    @Override
    public String toString() {
        return String.format("Chicken %s (age %d) can produce %.2f eggs per day.",
                this.name,
                this.age,
                this.calculateProductPerDay()
        );
    }
    private double calculateProductPerDay() {
        if (this.age < 6) {
            return 2;
        } else if (this.age < 12) {
            //  Next 6 years it produces 1 egg per day [6 - 11].
            return 1;
        }

        //  And after that, it produces 0.75 eggs per day.
        return 0.75;
    }
}
